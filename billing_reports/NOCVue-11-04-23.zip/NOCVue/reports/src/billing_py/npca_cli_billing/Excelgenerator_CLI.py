import conf1_CLI
import openpyxl
import pandas as pd 
from converter_CLI import *
from sql_data_extraction_CLI import *
from openpyxl.utils.dataframe import dataframe_to_rows
import os
#import traceback
class Report_Generator:

    def __init__(self, mon,year, appli):

        self.path1_save = conf1_CLI.path1
        self.path2_extract =conf1_CLI.path2
        self.path3_template =conf1_CLI.path3
        self.path4_sql= conf1_CLI.path4
        self.appli=appli.lower()
        self.m, self.y,self.m1 = Converter.mon_year(mon,year)
        self.from_date,self.to_date = Converter.to_from(mon,year)
        if self.from_date==None:
            raise TypeError
        
    def folder_check(self,file_name):
        try:
                folder1='generated_reports_LUMEN'
                folder2='generated_reports_BRS'
                self.file_path_extraction=None
                self.file_path_save=None

                if self.appli == 'lumen':
                    folder_path_extract = self.path2_extract + folder1
                    folder_path_save = self.path1_save + folder1
                elif self.appli == 'brightspeed':
                    folder_path_extract = self.path2_extract + folder2
                    folder_path_save = self.path1_save + folder2
                else:
                    raise ValueError("Invalid application name")
                    
                
                #FOR EXTRACTION PATH  check
                if not os.path.isdir(folder_path_extract): 
                    raise FileNotFoundError("Extraction Folder {} not found or does'nt exists".format(folder2))
                    
                folder_path_extract = os.path.join(folder_path_extract, '20' + self.y)
                if not os.path.isdir(folder_path_extract):
                    raise FileNotFoundError("Extraction Folder 20{} not found or does'nt exists".format(self.y))
                    return
                folder_path_extract = os.path.join(folder_path_extract, self.m1)
                if not os.path.isdir(folder_path_extract):
                    raise FileNotFoundError("Extraction Folder {} not found or does'nt exists".format(self.m1))
                    return
                files = os.listdir(folder_path_extract)
                if not files:
                    raise FileNotFoundError("Folder is empty: No file for extraction")
                else:
                    filename = files[0]
                    self.file_path_extraction = os.path.join(folder_path_extract, filename)

                #FOR SAVE PATH check
                if not os.path.isdir(folder_path_save): 
                    os.makedirs(folder_path_save)
                folder_path_save= os.path.join(folder_path_save, '20' + self.y)
                if not os.path.isdir(folder_path_save):
                    os.makedirs( folder_path_save)
                folder_path_save = os.path.join(folder_path_save, self.m1)
                if not os.path.isdir(folder_path_save):
                    os.makedirs(folder_path_save)
                files = os.listdir(folder_path_save)
                if file_name not in files:
                    self.file_path_save = os.path.join(folder_path_save, file_name)
                else :
                    raise FileExistsError("File Report already exists! for the given month and year {}".format( folder_path_save))
                
        except (ValueError, FileNotFoundError, FileExistsError) as e:
            print(f"Exception occurred while checking the folder: {e}")
            

                    

class CLI_Reports_adtran(Report_Generator):
    def excel_report(self):
        
        try:
            file_save= 'CLI_Billing_Report_{}_{}_{}-{}.xlsx'.format('Adtran', self.m, self.y, self.appli)
            super().folder_check(file_save)
            
            if self.file_path_save != None:
                print("Adtran File  Creation initiated")

        
                workbook = openpyxl.load_workbook(self.file_path_extraction )
                if workbook==None:
                    raise FileNotFoundError("Extraction File for {} Does'nt exist".format(self.appli))
                worksheet = workbook['CLI-Report Summary-Adtran']
                filtered_rows = []

                for row in worksheet.iter_rows(values_only=True, min_col=2, max_col=7, min_row=5, max_row=35):
                    if row[0] is None:
                        break
                    filtered_rows.append(list(row))

                df = pd.DataFrame(filtered_rows, columns=[' ', 'TotalSO#', 'Comm Error', 'Success', 'Failure', 'Success %'])

                
                wb = openpyxl.load_workbook(self.path3_template + 'template_cli.xlsx')
                if wb==None:
                    raise Exception("Error in Excelgenerator_adtran: template file not found")
                ws = wb.worksheets[0]
                ws.title="Adtran-CLI"
                


                for r, row in enumerate(dataframe_to_rows(df, index=False, header=False), start=5):
                    for c, val in enumerate(row, start=3):
                        ws.cell(row=r, column=c, value=val)

                sql_object = SqlDataExtractor()
                raw_sql_data = sql_object.extract_sql_data(self.from_date,self.to_date,'Adtran-Lumen',self.appli, self.path4_sql)
                result = [t[6:] for t in raw_sql_data]
                
                filtered_g = Converter.filter(result)
            
                ws1 = wb.worksheets[1]
                ws1.title="Failure-Split"
                df1 = pd.DataFrame(filtered_g, columns=['Date', 'Comm Error', 'Data Error', 'Gen Error', 'Total Failure'])

                for r1, row1 in enumerate(dataframe_to_rows(df1, index=False, header=False), start=4):
                    for c1, val1 in enumerate(row1, start=3):
                        ws1.cell(row=r1, column=c1, value=val1)

                wb.save(self.file_path_save)
            
                Converter.Excel_filter_CLI (self.file_path_save)
                wb.close()
                print("adtran saved")
        except Exception as e:
            (f"ExcelGenerator adtran_CLI Exception : {e}")
            # tb = traceback.extract_tb(e.__traceback__)
            # filename, line_no, func, line = tb[-1]
            # err_msg = f"Error occurred in line {filename, line_no, func, line }: {e}"
            # print(err_msg)
        



################################################################################################################################
class CLI_Reports_tellabs(Report_Generator):
    def excel_report(self):
        try:
            file_save= 'CLI_Billing_Report_{}_{}_{}-{}.xlsx'.format('tellabs',self.m, self.y, self.appli)
            file_save=super().folder_check(file_save)
            
            if self.file_path_save != None:
                print("Tellabs File Creation initiated")
            
                workbook = openpyxl.load_workbook(self.file_path_extraction )
                if workbook==None:
                    raise FileNotFoundError("Extraction File for {} Does'nt exist".format(self.appli))
                worksheet = workbook['CLI-Report Summary-TELLABS']
                filtered_rows = []

                for row in worksheet.iter_rows(values_only=True, min_col=2, max_col=7, min_row=5, max_row=35):
                    if row[0] is None:
                        break
                    filtered_rows.append(list(row))

                df = pd.DataFrame(filtered_rows, columns=[' ', 'TotalSO#', 'Comm Error', 'Success', 'Failure', 'Success %'])

                wb = openpyxl.load_workbook(self.path3_template + 'template_cli.xlsx')
                if wb==None:
                    raise Exception("Error in Excelgenerator_tellabs: tempalte file not found")
                ws = wb.worksheets[0]
                ws.title="Tellabs-CLI"


                for r, row in enumerate(dataframe_to_rows(df, index=False, header=False), start=5):
                    for c, val in enumerate(row, start=3):
                        ws.cell(row=r, column=c, value=val)

                sql_object = SqlDataExtractor()
                sql_data = sql_object.extract_sql_data(self.from_date,self.to_date,'Tellabs',self.appli, self.path4_sql)
                result = [t[6:] for t in sql_data]
                filtered_g = Converter.filter(result)
                ws1 =  wb.worksheets[1]
                ws1.title="Failure-Split"
                df1 = pd.DataFrame(filtered_g, columns=['Date', 'Comm Error', 'Data Error', 'Gen Error', 'Total Failure'])

                for r1, row1 in enumerate(dataframe_to_rows(df1, index=False, header=False), start=4):
                    for c1, val1 in enumerate(row1, start=3):
                        ws1.cell(row=r1, column=c1, value=val1)
                wb.save(file_save)

                Converter.Excel_filter_CLI(file_save)

                wb.close()
                print("tellabs saved")

        except Exception as e:
            (f"ExcelGenerator CLI_tellabs Exception : {e}")
            # tb = traceback.extract_tb(e.__traceback__)
            # filename, line_no, func, line = tb[-1]
            # err_msg = f"Error occurred in line {filename, line_no, func, line }: {e}"
            # print(err_msg)

