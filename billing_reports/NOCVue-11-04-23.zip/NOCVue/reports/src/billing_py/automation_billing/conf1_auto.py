from configparser import *
config_file = 'C:/Users/pavan.vasant/billing_reports/billing_reports/NOCVue/reports/src/billing_py/automation_billing/config.ini'
cf1 = ConfigParser()
try:
    cf1.read(config_file)
    path1 = cf1.get('file_path','save_path')
    path2 = cf1.get('file_path','extract_path')
    path3=  cf1.get('file_path','template_path')

except Exception as e:
    print(f"Error loading configuration file: {e}")
